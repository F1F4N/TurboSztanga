<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="edytuj.css">
    <link href='https://fonts.googleapis.com/css?family=Fredoka One' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Inter' rel='stylesheet'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script>
        function reminder(){
            var x = document.getElementById("haslo");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
</head>
<body>
    <div id="container">
        <div class="top">
            <a href="index.php"><img src="s.PNG" alt="Turbo Sztanga" class="top-img"></a>
        </div>
        
        <div class="top-mid">
            <div id="strgl"><p><a href="index.php">Strona główna<a></p></div>
            <div id="nav">
                <p>Treningi</p>
                <div id="treningi">
                    <script>
                        $(document).ready(function(){
                            $("#treningi").hide();
                            
                            $("#nav").hover(function(){
                                $("#treningi").slideDown(500);
                            });

                            $("#nav").mouseleave(function(){
                                $("#treningi").slideUp(500);
                            });
                        });
                    </script>

                    <p><a href="klata.html">Klata</a></p>
                    <p><a href="barki.html">Barki</a></p>
                    <p><a href="rece.html">Ręce</a></p>
                    <p><a href="nogi.html">Nogi</a></p>
                </div>
            </div>
            <div class="trener">
                <p><a href="trener.php">Trenerzy</a></p>
            </div>

            <div id="info">
                <p>O nas</p>
            </div>
        </div> 

        <div class="top-log">
            <a href="profil.php" class="konto">Moje konto</a>
        </div>
    </div>
    <div id="container2">
        <div id="left">
            <div class="left-container"></div>
        </div>

        <div id="midl">
            <div id="midl-left">
                <p class="photo-text">Zdjęcie profilowe</p>
                <p class="name-text">Imię</p>
                <p class="surname-text">Nazwisko</p>
                <p class="login-text">Login</p>
                <p class="new-haslo-text">Hasło</p>
                <p class="remind-text">Przypomnij hasło</p>
                <p class="opis-text">Opis</p>
                </div>
            <div id="midl-right">
            <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "strong_gym";
                // Połączenie z bazą
                $conn = new mysqli($servername, $username, $password, $dbname);
                if(isset($_COOKIE['login']) && isset($_COOKIE['haslo'])) {
                    // !beczkaksiadzmasło82!D
                    
                    // maslanyraj.cba.pl
                    // PROFILLEAB
                    //DB Aleksss
                    //DB Beczkaksi2!
                    $user = $_COOKIE['login'];
                    $pass = $_COOKIE['haslo'];
                    // echo"us: ".$user." has: ".$pass;
                    $q = "SELECT * FROM `users` WHERE `login` = '$user' AND `haslo` = '$pass'";
                    
                    $usr = "SELECT user_id FROM `users` WHERE `login` = '$user'";
                    $usri = $conn->query($usr);
                    $usrid = mysqli_fetch_assoc($usri);
                    $userid = $usrid['user_id'];
                    //dodac ze jesli userid jest juz wstawione w profilowych to usun poprzednie i ustaw to teraz ustawione
                    $result = $conn->query($q);
                        $row = mysqli_fetch_assoc($result);
                        echo"<div id='profil-user'>";
                        if($row) {
                            //ZDJECIE
                            ?>
                            <form method="post" enctype="multipart/form-data" class="form1">
                                <label for="pliki" class="wybierz-plik">WYBIERZ PLIK:</label><br>
                                <input type="file" class="plik" name="pliki" accept="img/user/*"><br>
                                <button type="submit" class="wybierz-plik-button" name="fileupld">UPLOAD</button>
                            </form> 
                            <?php
                            @$file_name = $_FILES['pliki']['name'];
                            @$file_tmp = $_FILES['pliki']['tmp_name'];
                            //jesli juz ustawiono kiedys zdjecie
                            $checky = "SELECT * FROM profilowe WHERE id_user = '$userid';";
                            $check = $conn->query($checky);
                            @$pfp_name =  "userpfp"."$userid".".jpg";
                            if(!empty($file_name)){
                                if($check->num_rows <= 0 ){
                                    $file_name = $_FILES['pliki']['name'];
                                    $sql = "INSERT INTO profilowe VALUES ('','$pfp_name','$file_name','$userid')";
                                    move_uploaded_file($file_tmp,"img/user/".$pfp_name);
                                    echo '<script>alert("USTAWIONO ZDJĘCIE PROFILOWE")</script>'; 
                                    mysqli_query($conn, $sql);
                                }
                                else{
                                    $del = "DELETE FROM profilowe WHERE id_user = $userid";
                                    $sql = "INSERT INTO profilowe VALUES ('','$pfp_name','$file_name','$userid')";
                                    mysqli_query($conn, $del);
                                    mysqli_query($conn, $sql);
                                    //przenies do foloderu ze zmieniona nazwa
                                    move_uploaded_file($file_tmp,"img/user/".$pfp_name);
                                    echo '<script>alert("ZAKULIZOWANO ZDJECIE PROFILOWE")</script>'; 
                                }
                            }

                            //WSZYSTKO FLAOT:RIGHT;
                            //IMIE
                            echo"<form method='POST'>";
                            echo"<div id='descriptions'>";
                            //IMIE
                            echo "<input type='text' name='imie' value='".$row['imie']."'class='input-name'></input><br>";
                            //NAZWISKO
                            echo "<input type='text' name='nazwisko' value='".$row['nazwisko']."'class='input-surname'></input><br>";
                            //LOGIN
                            echo "<input type='text' name='login' value='".$row['login']."'class='login-input'></input><br>";
                            //ZOBACZ HASLO
                            echo "<input type='password' id='haslo' name='haslo' value='".$row['haslo']."' readonly class='password-input'></input><br>";
                            echo"<button type='button' onclick='reminder()' class='remindpass-button'>PRZYPOMNIJ HASŁO</button><br>";
                            //OPIS
                            echo "<textarea rows='4' cols='50' placeholder='OPIS' name='opis' class='opis-input'>".$row['opis']."</textarea><br>";
                            //DOSWIADCZENIE
                            echo"</div>";
                            echo"<input type='submit' name='send' value='ZAPISZ ZMIANY'class='midl-right-button'>";
                            echo"</form>";
                            if(isset($_POST['send'])) {
                                // ZROBIĆ ABY DZIALALO
                                if($row['login'])
                                $q2 = "UPDATE `users` SET `imie`='".$_POST['imie']."',`nazwisko`='".$_POST['nazwisko']."',`login`='".$_POST['login']."',`haslo`='".$_POST['haslo']."',`opis`='".$_POST['opis']."' WHERE `user_id`=".$row['user_id']."";
                                $result = $conn->query($q2);
                                
                                echo"<script>alert('ZMIENIONO')</script>";
                            }
                        }
                        echo"<div id='backing'><a href='profil.php'><p>POWRÓT DO PROFILU</p></div>";
                        echo"</div>";
                }
            ?>
            
               
            </div>
        </div>

        <div id="right">
            <div class="right-container"></div>
        </div>
    </div>
    <div id="botom-stopka">
        <p>Copyright © 2023 | Turbo Sztanga Projekt Szkolny</p>
    </div>
</body>
</html>