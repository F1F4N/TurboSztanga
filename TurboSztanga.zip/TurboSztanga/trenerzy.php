<!DOCTYPE html>
<html lang="PL-pl">
<head>
    <meta charset="UTF-8"> <!-- Deklaracja kodowania znaków -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Ustawienie widoku na urządzeniach mobilnych -->
    <title>Document</title> <!-- Tytuł strony -->
    <link rel="stylesheet" type="text/css" href="trenerzystyle.css"> <!-- Link do zewnętrznego pliku CSS -->
    <link href='https://fonts.googleapis.com/css?family=Fredoka One' rel='stylesheet'> <!-- Link do importowania czcionki Fredoka One -->
    <link href='https://fonts.googleapis.com/css?family=Inter' rel='stylesheet'> <!-- Link do importowania czcionki Inter -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script> <!-- Link do biblioteki jQuery -->
</head>
<body>
    <div id="container"> <!-- Kontener główny -->
        <div class="top">
            <a href="index.php"><img src="s.PNG" alt="Turbo Sztanga" class="top-img"></a> <!-- Logo z linkiem powrotu do strony głównej -->
        </div>
        
        <div class="top-mid"> <!-- Górna część nagłówka -->
            <div id="strgl"><p><a href="index.php">Strona główna<a></p></div> <!-- Link do strony głównej -->
            <div id="nav">
                <p>Treningi</p> <!-- Nagłówek "Treningi" -->
                <div id="treningi">
                    <script>
                        // Skrypt jQuery do obsługi menu rozwijanego
                        $(document).ready(function(){
                            $("#treningi").hide();
                            
                            $("#nav").hover(function(){
                                $("#treningi").slideDown(500);
                            });

                            $("#nav").mouseleave(function(){
                                $("#treningi").slideUp(500);
                            });
                        });
                    </script>
                    <p><a href="klata.html">Klata</a></p>
                    <p><a href="barki.html">Barki</a></p>
                    <p><a href="rece.html">Ręce</a></p>
                    <p><a href="nogi.html">Nogi</a></p>
                </div>
            </div>
            <div class="trener">
                <p><a href="trenerzy.php">Trenerzy</a></p> <!-- Link do sekcji "Trenerzy" -->
            </div>

            <div id="info">
                <p>O nas</p> <!-- Nagłówek "O nas" -->
            </div>
        </div> 

        <div class="top-log">
            <a href="profil.php" class="konto">Moje konto</a> <!-- Link do sekcji "Moje konto" -->
        </div>
    </div>

    <div id="container2"> <!-- Drugi kontener główny -->
        <div id="left"> <!-- Lewa część kontenera -->
            <div class="left-container">
                <!-- Tu można dodać zawartość lewej części kontenera -->
            </div>
        </div>

        <div id="midl"> <!-- Środkowa część kontenera -->
            <div id="midl_logo">
                <div id="midl-logo-text-trener">
                    <p>Trenerzy</p> <!-- Nagłówek "Trenerzy" -->
                </div>
            </div>
            <div id="odstep">
            </div>            
            
            <?php
                //STRONA WSZYSTKO ZAWIERA WSZYSTKIE RZECZY DO POD STRON (PRAWIE WSZYSTKO)
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "strong_gym";
                    // Połączenie z bazą
                    $conn = new mysqli($servername, $username, $password, $dbname);


                    //WYPISZ TRENERÓW
                    $q1 = "SELECT * FROM `trenerzy`";
                    $result = $conn->query($q1);
                    //WYPISUJE WSZYSTKICH TRENERÓW

                    while($row = mysqli_fetch_assoc($result)){


                        //IMIE TRENERA
                        echo"<div id='trener-box1'>";
                        //ZDJECIE 
                        // ROZMIARY ZDJEC 600 x 375 [px]
                        echo"<div id='img-back'>";echo "<img id='imgs' src='img/trener/".$row["zdjecie"]."' </img>"; echo"</div>";

                        //WSZYSTKO FLAOT:RIGHT;

                        echo"<div id='descriptions'>";

                        //IMIE
                        echo"<div id='trener-name'>";echo "<p>Trener: ". $row["imię"]."</p>";echo"</div>";
                        //OPIS
                        echo"<div id='trener-opis'>";echo "<p> O nim: ". $row["Opis"]."</p>";echo"</div>";
                        //DOSWIADCZENIE
                        echo"<div id='doswiadczenie'>";echo "<p>Doświadczenie: ".$row["doswiadczenie"]."</p>";echo"</div>";
                        echo"</div>";
                        echo"</div>";
                    }
                    //KONIEC SEKCJI
                ?>
        </div>

        <div id="right"> <!-- Prawa część kontenera -->
            <div class="right-container">
                <!-- Tu można dodać zawartość prawej części kontenera -->
            </div>
        </div>
    </div>

    <div id="botom-stopka">
        <!-- Tu można dodać stopkę strony -->
        <p>Copyright © 2023 | Turbo Sztanga Projekt Szkolny</p>
    </div>
</body>
</html>