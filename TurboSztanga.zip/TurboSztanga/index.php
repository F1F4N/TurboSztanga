<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href='https://fonts.googleapis.com/css?family=Fredoka One' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Inter' rel='stylesheet'>
<link rel="icon" href="s.png" sizes="48x48" type="image/png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
</head>
<body>
    <div id="container">
        <div class="top">
                <a href="index.php"><img src="s.PNG" alt="Turbo Sztanga" class="top-img"></a>
        </div>
        
        <div class="top-mid">
        <div id="strgl"><p><a href="index.php">Strona główna<a></p></div>
            <div id="nav">
                <p>Treningi</p>
                <div id="treningi">
                    <script>
                        $(document).ready(function(){
                                $("#treningi").hide();
                            
                                $("#nav").hover(function(){
                                    $("#treningi").slideDown(500);
                                });

                                $("#nav").mouseleave(function(){
                                    $("#treningi").slideUp(500);
                                });
                            });
                    </script>

                    <p><a href="klata.html">Klata</a></p>
                    <p><a href="barki.html">Barki</a></p>
                    <p><a href="rece.html">Ręce</a></p>
                    <p><a href="nogi.html">Nogi</a></p>
                </div>
            </div>
            <div class="trener">
                <p><a href="trenerzy.php">Trenerzy</a></p>
            </div>

            <div id="info">
                <a href="onas.html"><p>O nas</p></a>
            </div>
            
        </div> 

        <div class="top-log">
        <a href="profil.php" class="konto">Moje konto</a>
        </div>
    </div>
    <div id="container2">
        <div id="left">
            <div class="left-container">

                </div>
        </div>

        <div id="midl">
            <div id="midl_logo">
                <img src="s.PNG">
            </div>
            <div id="odstep">
            </div>
            <p>Aktualności</p>
            <div id="artykol-2">
                <div class="zdjecie">
                    <a href="rece.html"><img class="zdjecie" src="rece.jfif"></a>
                </div>
                <div id="artykul2-name">
                    Trening na ręce
                </div>
                
            </div>
            
            
            <div id="artykol-1">
                <div class="zdjecie">
                    <a href="barki.html"><img class="zdjecie" src="barki.jfif"></a>
                </div>

                <div id="artykul-name">
                    Trening na barki
                </div>
            </div>
            
        </div>

        <div id="right">
            <div class="right-container">

            </div>
        </div>
    </div>
    <div id="botom-stopka">
<p>Copyright © 2023 | Turbo Sztanga Projekt Szkolny</p>
    </div>

</body>
</html>