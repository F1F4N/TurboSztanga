<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie</title>
    <script>
            function resetForm() {
                document.getElementById('formlogin').reset();
                setTimeout(function() {
                    resetForm();
                window.location.href = 'profil.php';
                }, 500);
                }
    </script>
    <link rel="stylesheet" type="text/css" href="zalogujstyle.css">
    <link href='https://fonts.googleapis.com/css?family=Fredoka One' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Inter' rel='stylesheet'>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
</head>
<body>
    <div id="container">
        <div class="top">
            <a href="index.php"><img src="s.PNG" alt="Turbo Sztanga" class="top-img"></a>
        </div>
        
        <div class="top-mid">
            <div id="strgl"><p><a href="index.php">Strona główna<a></p></div>
            <div id="nav">
                <p>Treningi</p>
                <div id="treningi">
                    <script>
                        $(document).ready(function(){
                            $("#treningi").hide();
                            
                            $("#nav").hover(function(){
                                $("#treningi").slideDown(500);
                            });

                            $("#nav").mouseleave(function(){
                                $("#treningi").slideUp(500);
                            });
                        });
                    </script>

<p><a href="klata.html">Klata</a></p>
                    <p><a href="barki.html">Barki</a></p>
                    <p><a href="rece.html">Ręce</a></p>
                    <p><a href="nogi.html">Nogi</a></p>
                </div>
            </div>
            <div class="trener">
                <p><a href="trener.php">Trenerzy</a></p>
            </div>

            <div id="info">
                <p>O nas</p>
            </div>
        </div> 

        <div class="top-log">
            <a href="profil.php" class="konto">Moje konto</a>
        </div>
    </div>
    <div id="container2">
        <div id="left">
            <div class="left-container"></div>
        </div>

        <div id="midl">
            <img src="a.PNG" class="sign-img">
            <div id="sign-text">
                <p>Witaj ponownie Misztrzu!</p>
            </div>
            <form action="zaloguj.php" method="POST" id="formlogin">
                <div id="login">
                <input type="text" placeholder="Login" id="login" name="login" required>
                </div>
                <div id="mail">
                <input type="password" placeholder="Hasło" id="haslo" name="haslo" autocomplete="off">
                </div>
                <div id="sign-on-button">
                <input type="submit" value="Zaloguj się">
                </div>
            </form>
            <?php
                 $servername = "localhost";
                 $username = "root";
                 $password = "";
                 $dbname = "strong_gym";
                 // Połączenie z bazą
                 $conn = new mysqli($servername, $username, $password, $dbname);
                    //LOGOWANIE użytkownika
                    
                    @$login = $_POST['login'];
                    @$haslo = $_POST['haslo'];
                    
                    if(isset($login)){
                        // echo"LOGIN: ".$login.", HASŁO: ".$haslo;

                        $q2 = "SELECT * FROM `users` WHERE `login` = '$login' AND `haslo` = '$haslo'";
                        $result = $conn->query($q2);

                        //JEŚLI pytanie ma wiecej niz jedna odpowiedz (jest poprawne)

                        if ($result->num_rows > 0) {
                        // Użytkownik istnieje, ustaw cookie.

                        setcookie("login", $login, time() + (86400 * 30), "/"); // 86400 = 1 dzień
                        setcookie("haslo", $haslo, time() + (86400 * 30), "/"); // 86400 = 1 dzień
                        //ZALOGOWANO ---> KONTYNUACJA

                        echo"<p>Zalogowano Poprawnie</p>";
                        // RESETUJE STRONE PO POPRAWNYM ZALOGOWANIU
                        echo"<script>resetForm()</script>";    
                        } else{
                            // Jeśli nie znaleziono takiego usera
                            echo"<p>Podano Nieprawidłowe Dane</p>";

                        }} 
                    else {
                        if (!empty($_POST['login']) && !empty($_POST['haslo'])) {
                            // Użytkownik nie istnieje, wyświetl komunikat o błędzie
                            echo "<p>Błąd logowania. Spróbuj ponownie.</p>";
                        }
                    }
                ?>
            <div id="have-account-text">
                <p>Nie masz konto? <a href="zarejestruj.php">Dołącz do nas!</a></p>
            </div>
        </div>

        <div id="right">
            <div class="right-container"></div>
        </div>
    </div>
    <div id="botom-stopka">
        <p>Copyright © 2023 | Turbo Sztanga Projekt Szkolny</p>
    </div>
</body>
</html>