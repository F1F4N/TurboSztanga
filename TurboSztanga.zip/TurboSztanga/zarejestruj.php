<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REJESTRACJA</title>
    <script>
        function resetForm() {
                document.getElementById('rejespost').reset();
                setTimeout(function() {
                    resetForm();
                // window.location.href = 'index.php';
                }, 500);
            }
    </script>
    <link rel="stylesheet" type="text/css" href="rejestrujstyle.css">
    <link href='https://fonts.googleapis.com/css?family=Fredoka One' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Inter' rel='stylesheet'>
    <link rel="icon" href="s.png" sizes="48x48" type="image/png">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
</head>
<body>
    <div id="container">
        <div class="top">
            <a href="index.php"><img src="s.PNG" alt="Turbo Sztanga" class="top-img"></a>
        </div>
        
        <div class="top-mid">
            <div id="strgl"><p><a href="index.php">Strona główna<a></p></div>
            <div id="nav">
                <p>Treningi</p>
                <div id="treningi">
                    <script>
                        $(document).ready(function(){
                            $("#treningi").hide();
                            
                            $("#nav").hover(function(){
                                $("#treningi").slideDown(500);
                            });

                            $("#nav").mouseleave(function(){
                                $("#treningi").slideUp(500);
                            });
                        });
                    </script>

                    <p><a href="klata.html">Klata</a></p>
                    <p><a href="barki.html">Barki</a></p>
                    <p><a href="rece.html">Ręce</a></p>
                    <p><a href="nogi.html">Nogi</a></p>
                </div>
            </div>
            <div class="trener">
                <p><a href="trener.php">Trenerzy</a></p>
            </div>

            <div id="info">
                <p>O nas</p>
            </div>
        </div> 

        <div class="top-log">
            <a href="profil.php" class="konto">Moje konto</a>
        </div>
    </div>
    <div id="container2">
        <div id="left">
            <div class="left-container"></div>
        </div>

        <div id="midl">
            <img src="a.PNG" class="sign-img">
            <div id="sign-text">
                <p>Witaj Misztrzu!</p>
            </div>
            <form action="zarejestruj.php" method="POST" id="rejespost">
                <div id="name">
                    <input type="text" placeholder="Imie" id="rimie" name="rimie">
                </div>
                <div id="surname">
                    <input type="text" placeholder="Nazwisko" id="rnazwisko" name="rnazwisko">
                </div>
                <div id="login">
                    <input type="text" placeholder="login" id="rlogin" name="rlogin">
                </div>
                <div id="mail">
                    <input type="password" placeholder="Hasło" id="rhaslo" name="rhaslo" autocomplete="off">
                </div>
                <div id="password">
                    <input type="password" placeholder="Potwierdź Hasło" id="rpowhaslo" name="rpowhaslo" autocomplete="off">
                </div>
                <div id="sign-on-button">
                    <input type="submit" placeholder="Zarejestruj się" name="register">
                </div>
            </form>
            <?php
                 $servername = "localhost";
                 $username = "root";
                 $password = "";
                 $dbname = "strong_gym";
                 // Połączenie z bazą
                 $conn = new mysqli($servername, $username, $password, $dbname);
                 
                //REJESTRACJA USER
                $rimie = $_POST["rimie"];
                $rnazwisko = $_POST["rnazwisko"];
                $rlogin = $_POST["rlogin"];
                $rhaslo = $_POST["rhaslo"];
                $rpowhaslo = $_POST["rpowhaslo"];

                if (isset($_POST['register'])) {
                    // jesli kliknieto Guzik Rejestruj
                    if($rimie !="" && $rnazwisko !="" && $rlogin !="" && $rhaslo !="" && $rpowhaslo !=""){
                        //wypisz wszystkie informacje
                        // echo"Imie: ".$rimie.", Nazwisko: ".$rnazwisko.", Login: ".$rlogin.", Haslo: ".$rhaslo."<br>";

                        //CZY KONTO ISTNIEJE?
                            $q3= "SELECT login FROM `users` WHERE login='$rlogin'";
                            $result = $conn->query($q3);

                            if($result->num_rows > 0 ){
                        //ISTNIEJE KONTO Z DANYM LOGINEM
                                echo"Dany Login Jest już zajęty";
                            }
                            else{
                                //JEŚLI HASŁO SIĘ ZGADZA Z POWTÓRZONYM
                                if($rhaslo == $rpowhaslo){
                                    $q4= "INSERT INTO `users` VALUES ('',NULL,'".$rimie."','".$rnazwisko."','".$rlogin."','".$rhaslo."','Nie Podano Opisu')";
                                    $result = $conn->query($q4);
                                    //ZAREJESTROWANO
                                echo'<script>alert("UTWORZONO KONTO!")</script>';
                                echo"<script>resetForm()</script>"; 
                                }
                                else{
                                    echo"Źle powtórzono hasło";
                                }
                            }
                    }
                    else{
                        echo"Nie podano którejś z informacji";
                    }
                }
                ?>
            <div id="have-account-text">
                <p>Masz konto? <a href="zaloguj.php">Zaloguj się!</a></p>
            </div>
        </div>

        <div id="right">
            <div class="right-container"></div>
        </div>
    </div>
    <div id="botom-stopka">
        <p>Copyright © 2023 | Turbo Sztanga Projekt Szkolny</p>
    </div>
</body>
</html>