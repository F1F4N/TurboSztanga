<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Importowanie arkusza stylów CSS -->
    <link rel="stylesheet" type="text/css" href="trenerstyle.css">
    <!-- Importowanie dwóch różnych fontów z Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Fredoka One' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Inter' rel='stylesheet'>
    <!-- Importowanie biblioteki jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script>
        function niezalogowano(){
            alert("NIE ZALOGOWANO");
                window.location = 'zaloguj.php';
        }
    </script>
</head>
<body>
    <!-- Główny kontener strony -->
    <div id="container">
        <!-- Górna część strony -->
        <div class="top">
            <!-- Logo strony -->
            <a href="index.php"><img src="s.PNG" alt="Turbo Sztanga" class="top-img"></a>
        </div>
        
        <!-- Środkowa część górnej belki nawigacyjnej -->
        <div class="top-mid">
            <!-- Przycisk "Strona główna" -->
            <div id="strgl"><p><a href="index.php">Strona główna</a></p></div>
            
            <!-- Nawigacja główna -->
            <div id="nav">
                <p>Treningi</p>
                <!-- Podmenu "Treningi" -->
                <div id="treningi">
                    <!-- Skrypt jQuery do pokazywania/ukrywania podmenu po najechaniu myszką -->
                    <script>
                        $(document).ready(function(){
                            $("#treningi").hide();
                            
                            $("#nav").hover(function(){
                                $("#treningi").slideDown(500);
                            });

                            $("#nav").mouseleave(function(){
                                $("#treningi").slideUp(500);
                            });
                        });
                    </script>

                    <!-- Opcje podmenu "Treningi" -->
                    <p><a href="klata.html">Klata</a></p>
                    <p><a href="barki.html">Barki</a></p>
                    <p><a href="rece.html">Ręce</a></p>
                    <p><a href="nogi.html">Nogi</a></p>
                </div>
            </div>
            
            <!-- Przycisk "Trenerzy" -->
            <div class="trener">
                <p><a href="trenerzy.php">Trenerzy</a></p>
            </div>

            <!-- Przycisk "O nas" -->
            <div id="info">
                <p>O nas</p>
            </div>
        </div> 

        <!-- Prawa część górnej belki nawigacyjnej -->
        <div class="top-log">
            <!-- Przycisk "Moje konto" -->
            <a href="profil.php" class="konto">Moje konto</a>
        </div>
    </div>
    <div id="container2">
        <!-- Lewa kolumna strony -->
        <div id="left">
            <div class="left-container">
            <!-- Zawartość lewej kolumny -->
            </div>
        </div>

        <!-- Środkowa kolumna strony -->
        <div id="midl">
            <!-- Informacje o trenerze -->
            <div id="trener-info">
                <?php
                    //STRONA O UZYTKOWNIK PO KLIKNIECIU MOJE KONTO W PRAWYM GORNYM ROGU
                    //WYSWIETLA PROFILOWE ->IMIE -> NAZWISKO
                    //2 GUZIKI (WYLOGUJ) & (EDYTUJ PROFIL) --> PRZENOSI DO uzytkownik-settings.php
                    //POD SPODEM OPIS
                    //
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "strong_gym";
                    // Połączenie z bazą
                    $conn = new mysqli($servername, $username, $password, $dbname);


                    //WYPISZ TRENERÓW
                    $q1 = "SELECT * FROM `users`";
                    $result = $conn->query($q1);
                    $row = mysqli_fetch_assoc($result);
                    //WYPISUJE UZYTKOWNIKA PRZYPISANEGO Z LOGINU I HASLA JESLI SIE ZGADZAJA -JESLI NIE TO PRZENIES NA STRONE Z LOGOWANIEM

                    
                    if(isset($_COOKIE['login']) && isset($_COOKIE['haslo'])) {

                        $user = $_COOKIE['login'];
                        $pass = $_COOKIE['haslo'];
                        // echo"us: ".$user." has: ".$pass;

                        $q2 = "SELECT * FROM `users` WHERE `login` = '$user' AND `haslo` = '$pass'";
                        $result2 = $conn->query($q2);
                        $row2 = mysqli_fetch_assoc($result2);
                        echo"<div id='uzytkownicy'>";
                        if($row2) {
                            //IMIE TRENERA
                            //ZDJECIE 
                            // ROZMIARY ZDJEC 600 x 375 [px]
                            //USTAWIANIE PROFILOWEGO
                            $usr = "SELECT user_id FROM `users` WHERE `login` = '$user'";
                            $usri = $conn->query($usr);
                            $usrid = mysqli_fetch_assoc($usri);
                            $userid = $usrid['user_id'];
                            @$pfp_name =  "userpfp"."$userid".".jpg";
                            //SPRAWDZ CZY JEST JUŻ JAKIEŚ USTAWION
                            $check = "SELECT id_user FROM `profilowe` WHERE id_user = $userid;";
                            $pfpcheck = $conn->query($check);
                            if($pfpcheck->num_rows <= 0 ){
                                //jesli nie istnieje
                                echo"<div id='midl-foto-trener'>";echo "<img id='imgs' src='img/user/defaultpfp.jpg' </img>";echo"</div>";
                            }else{
                                // jesli istnieje
                                echo"<div id='midl-foto-trener'>";echo "<img id='imgs' src='img/user/$pfp_name'</img>";echo"</div>";
                            }
                            //WSZYSTKO FLAOT:RIGHT;

                            echo"<div id='descriptions'>";

                            //IMIE
                            echo"<div id='names'>";
                            echo" <div id='trener-name'>";echo "<span>".$row2['imie']." ".$row2["nazwisko"]."</span>";
                            ?>
                            <div id="edit">
                                <a href="edutyj.php"><button class="button" type="button">Edytuj profil</button></a>
                            </div>
                            <div id="logout">
                                <form method="POST">
                                    <input class="button" type="submit" name="logout" value="Wyloguj">
                                    <?php
                                        if(isset($_POST['logout'])) {
                                            // COOKIES WYLOGOWYWANIE
                                            // ZROBIĆ!
                                            setcookie("login", $user, time() - 3600, "/"); // 86400 = 1 dzień
                                            setcookie("haslo", $pass, time() - 3600, "/"); // 86400 = 1 dzień
                                            header("Location: zaloguj.php");
                                        }
                                    ?>
                                </form>
                            </div>
                            <?php
                            echo"</div>";
                            //OPIS
                            ?>
                            </div>     
            </div>
                <div id="odstep"></div>
                            <?php
                            echo" <div id='opis'>";echo "<p id='opiss'> O mnie: ". $row2["opis"]."</p>";echo"</div>";
                            //DOSWIADCZENIE
                            echo"</div>";
                        }
                        else{
                            header("Location: zaloguj.php");
                        }
                    }
                    else{
                        //PRZENIES NA STRONE Z LOGOWANIEM
                        echo"<script>niezalogowano()</script>";
                    }
                    echo"</div>";
                ?>           
        </div>

        <!-- Prawa kolumna strony -->
        <div id="right">
            <div class="right-container">
            <!-- Zawartość prawej kolumny -->
            </div>
        </div>
    </div>
    <!-- Stopka strony -->
    <div id="botom-stopka">
        <!-- Informacje o prawach autorskich -->
        <p>Copyright © 2023 | Turbo Sztanga Projekt Szkolny</p>
    </div>
</body>
</html>